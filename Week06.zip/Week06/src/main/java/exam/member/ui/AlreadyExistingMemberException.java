package exam.member.ui;

public class AlreadyExistingMemberException extends RuntimeException{

}

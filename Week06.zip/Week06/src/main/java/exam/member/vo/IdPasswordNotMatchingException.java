package exam.member.vo;

public class IdPasswordNotMatchingException extends RuntimeException {
   // 예외처리로 구성하고 싶은 코드 작성해 주면됩니다.
   
}

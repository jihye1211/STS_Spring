package exam.member.service;

import exam.member.vo.RegisterRequest;

public interface MemberRegisterService {
	public void regist(RegisterRequest req);

}

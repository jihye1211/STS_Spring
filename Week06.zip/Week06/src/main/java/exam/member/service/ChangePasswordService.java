package exam.member.service;

public interface ChangePasswordService {
	public void changePassword(String email,String oldPassword,String newPassword);

}

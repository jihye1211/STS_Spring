package exam.member.service;

public interface MemberListPrinterService {
	public void printAll();

}

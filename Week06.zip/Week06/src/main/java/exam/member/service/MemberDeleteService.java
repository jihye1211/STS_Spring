package exam.member.service;

public interface MemberDeleteService {
	public void delete(String email);

}
